import express from "express";
import cors from "cors";

const app = express();
const PORT = 3000;

// Middleware
app.use(cors({
  origin: "http://localhost:5173"
}));

app.use(express.json());

// API Home
app.get("/", (req, res) => {
  res.json({
    message: "PAMAKYABAETA Backend API is running!"
  });
});

// Website information
app.get("/api/home", (req, res) => {
  res.json({
    websiteName: "PAMAKYABAETA",
    tagline:
      "Rooted in Compassion, Connected through Pamakyabe.",
    location: "Mabalacat City, Pampanga"
  });
});

// Advocacy information
app.get("/api/advocacies", (req, res) => {
  res.json([
    {
      id: 1,
      title: "Education for All",
      description:
        "Promoting inclusive education for Aeta children and youth."
    },
    {
      id: 2,
      title: "Cultural Preservation",
      description:
        "Encouraging respect for Indigenous culture and heritage."
    },
    {
      id: 3,
      title: "Community Empowerment",
      description:
        "Promoting community participation and livelihood awareness."
    }
  ]);
});

// Team members
app.get("/api/team", (req, res) => {
  res.json([
    { id: 1, name: "Kyla Jouprieh Domingo", role: "Team Member" },
    { id: 2, name: "John Vladimir Gopez", role: "Team Member" },
    { id: 3, name: "Lance Quan", role: "Team Member" },
    { id: 4, name: "Marc Jan Manalo", role: "Team Member" },
    { id: 5, name: "John Rafael Garcia", role: "Team Member" }
  ]);
});

// Mission and vision
app.get("/api/about", (req, res) => {
  res.json({
    mission:
      "To promote awareness and cultural appreciation of Aeta communities.",
    vision:
      "A society where Indigenous communities are respected and their voices are heard."
  });
});

// Start backend server
app.listen(PORT, () => {
  console.log(
    `PAMAKYABAETA API running at http://localhost:${PORT}`
  );
});
