import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import About from "./pages/About";

function App() {
  return (
    <BrowserRouter>
      {/* SHARED NAVIGATION */}
      <Navbar />

      {/* WEBSITE PAGES */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
      </Routes>

      {/* SHARED FOOTER */}
      <Footer />
    </BrowserRouter>
  );
}

export default App;
