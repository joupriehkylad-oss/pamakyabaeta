function TeamCard({ name, role, image }) {
  return (
    <article className="team-card">
      <div className="team-photo">
        <img
          src={image}
          alt={`Portrait of ${name}`}
          onError={(event) => {
            event.currentTarget.src =
              "/images/team/default.png";
          }}
        />
      </div>

      <div className="team-details">
        <h3>{name}</h3>
        <p>{role}</p>
      </div>
    </article>
  );
}

export default TeamCard;
