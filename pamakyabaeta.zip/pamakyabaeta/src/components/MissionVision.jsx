
function MissionVision() {
  return (
    <section className="mission-vision-section">
      <div className="mission-vision-container">

        <div className="mission-vision-heading">
          <span className="mission-vision-label">
            WHAT DRIVES US
          </span>

          <h2>Our Mission & Vision</h2>

          <p>
            Our commitment to awareness, cultural
            respect, and community solidarity.
          </p>
        </div>

        <div className="mission-vision-grid">

          <article className="mission-card">
            <div className="mission-vision-icon">
              🎯
            </div>

            <h3>Our Mission</h3>

            <p>
              To promote awareness, cultural
              appreciation, and meaningful solidarity
              with Aeta Indigenous communities in
              Mabalacat City through accessible
              digital information and advocacy.
            </p>
          </article>

          <article className="vision-card">
            <div className="mission-vision-icon">
              👁️
            </div>

            <h3>Our Vision</h3>

            <p>
              A society where Indigenous communities
              are respected, their cultural heritage
              is valued, and their voices are heard
              in decisions affecting their future.
            </p>
          </article>

        </div>
      </div>
    </section>
  );
}

export default MissionVision;
