
function CommunityInfo() {
  return (
    <section className="community-section">
      <div className="community-container">

        <div className="community-image">
          <img
            src="/images/aeta-community.jpg"
            alt="Aeta community in Mabalacat City"
          />
        </div>

        <div className="community-content">
          <span className="community-label">
            GET TO KNOW THE COMMUNITY
          </span>

          <h2>
            The Aeta Community of
            <span> Mabalacat City</span>
          </h2>

          <p>
            Aeta communities are among the Indigenous
            Peoples of the Philippines, with a rich
            cultural heritage and a long history in
            Central Luzon.
          </p>

          <p>
            In Mabalacat City, Pampanga, Aeta
            communities continue to preserve their
            identities, traditions, and connections
            to their ancestral lands.
          </p>

          <p>
            PAMAKYABAETA aims to encourage cultural
            appreciation, Indigenous inclusion,
            and meaningful community solidarity.
          </p>

          <div className="community-highlight">
            Culture • Heritage • Community
          </div>
        </div>

      </div>
    </section>
  );
}

export default CommunityInfo;
