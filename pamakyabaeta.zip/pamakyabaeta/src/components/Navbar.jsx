
import { useState } from "react";
import { NavLink } from "react-router-dom";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <header className="site-header">
      <nav className="navbar">

        {/* WEBSITE BRAND */}
        <NavLink
          to="/"
          className="logo"
          onClick={closeMenu}
        >
          <h2>PAMAKYABAETA</h2>
          <p>
            Rooted in Compassion, Connected through{" "}
            <em>Pamakyabe</em>.
          </p>
        </NavLink>

        {/* MOBILE MENU BUTTON */}
        <button
          type="button"
          className="menu-toggle"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? "✕" : "☰"}
        </button>

        {/* NAVIGATION LINKS */}
        <div
          id="primary-navigation"
          className={`nav-links ${menuOpen ? "open" : ""}`}
        >
          <NavLink to="/" end onClick={closeMenu}>
            Home
          </NavLink>

          <NavLink to="/about" onClick={closeMenu}>
            About Us
          </NavLink>
        </div>

      </nav>
    </header>
  );
}

export default Navbar;
