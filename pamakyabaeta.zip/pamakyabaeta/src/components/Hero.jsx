
import { Link } from "react-router-dom";

function Hero() {
  return (
    <section className="hero">
      <div className="hero-container">

        <div className="hero-content">
          <span className="hero-label">
            PAMAKYABAETA • MABALACAT CITY
          </span>

          <h1>
            Together for the
            <span> Aeta Community.</span>
          </h1>

          <p className="hero-description">
            Celebrating Indigenous heritage,
            promoting awareness, and building
            meaningful connections with Aeta
            communities in Mabalacat City, Pampanga.
          </p>

          <Link to="/about" className="hero-button">
            Discover Our Story →
          </Link>
        </div>

        <div className="hero-image">
          <img
            src="/images/community.jpg"
            alt="Aeta community in Mabalacat City"
          />
        </div>

      </div>
    </section>
  );
}

export default Hero;
