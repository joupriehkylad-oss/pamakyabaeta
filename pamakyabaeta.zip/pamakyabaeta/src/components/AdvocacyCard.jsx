
function AdvocacyCard({ icon, title, description }) {
  return (
    <article className="advocacy-card">
      <div className="advocacy-icon" aria-hidden="true">
        {icon}
      </div>

      <h3>{title}</h3>

      <p>{description}</p>
    </article>
  );
}

export default AdvocacyCard;
