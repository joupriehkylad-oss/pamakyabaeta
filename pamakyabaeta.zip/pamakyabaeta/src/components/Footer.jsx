import { Link } from "react-router-dom";

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="footer-container">

        {/* WEBSITE INFORMATION */}
        <div className="footer-column footer-about">
          <h2>PAMAKYABAETA</h2>

          <p className="footer-tagline">
            Rooted in Compassion, Connected through{" "}
            <em>Pamakyabe</em>.
          </p>

          <p>
            An independent student-led advocacy website
            promoting awareness, cultural appreciation,
            and solidarity with Aeta Indigenous
            communities in Mabalacat City, Pampanga.
          </p>
        </div>

        {/* QUICK LINKS */}
        <div className="footer-column">
          <h3>Quick Links</h3>

          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>

            <li>
              <Link to="/about">About Us</Link>
            </li>
          </ul>
        </div>

        {/* ADVOCACY AREAS */}
        <div className="footer-column">
          <h3>Our Advocacy</h3>

          <ul>
            <li>Education for All</li>
            <li>Cultural Preservation</li>
            <li>Community Empowerment</li>
          </ul>
        </div>

      </div>

      {/* COPYRIGHT SECTION */}
      <div className="footer-bottom">
        <p>
          © {currentYear} PAMAKYABAETA.
          All rights reserved.
        </p>

        <p>
          Made with compassion for community awareness.
        </p>
      </div>
    </footer>
  );
}

export default Footer;
