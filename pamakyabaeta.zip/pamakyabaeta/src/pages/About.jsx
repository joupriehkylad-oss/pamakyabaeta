import TeamCard from "../components/TeamCard";
import team from "../data/team";

function About() {
  return (
    <main className="about-page">

      {/* ABOUT PAGE INTRODUCTION */}
      <section className="about-hero">
        <div className="about-hero-content">

          <span className="about-label">
            GET TO KNOW PAMAKYABAETA
          </span>

          <h1>Who We Are</h1>

          <p>
            PAMAKYABAETA is a student-led nonprofit
            awareness and advocacy website dedicated
            to promoting cultural appreciation,
            inclusivity, and solidarity with Aeta
            Indigenous communities in Mabalacat City,
            Pampanga.
          </p>

          <p>
            Through technology, we aim to share
            meaningful information, encourage
            understanding, and inspire people
            to respect and support Indigenous
            communities.
          </p>

        </div>
      </section>

      {/* MEET THE TEAM */}
      <section className="team-section">
        <div className="team-container">

          <div className="team-heading">
            <span className="team-label">
              THE PEOPLE BEHIND PAMAKYABAETA
            </span>

            <h2>Meet Our Team</h2>

            <p>
              We are Information Technology students
              working together to create an accessible
              platform for community awareness and
              cultural appreciation.
            </p>
          </div>

          <div className="team-grid">
            {team.map((member) => (
              <TeamCard
                key={member.id}
                name={member.name}
                role={member.role}
                image={member.image}
              />
            ))}
          </div>

        </div>
      </section>

    </main>
  );
}

export default About;
