import Hero from "../components/Hero";
import CommunityInfo from "../components/CommunityInfo";
import AdvocacyCard from "../components/AdvocacyCard";
import MissionVision from "../components/MissionVision";

import advocacies from "../data/advocacies";

function Home() {
  return (
    <main>
      {/* HERO SECTION */}
      <Hero />

      {/* AETA COMMUNITY SECTION */}
      <CommunityInfo />

      {/* OUR ADVOCACY SECTION */}
      <section className="advocacies-section">
        <div className="advocacies-container">

          <div className="advocacies-heading">
            <span className="advocacies-label">
              WHAT WE ADVOCATE
            </span>

            <h2>Our Areas of Advocacy</h2>

            <p>
              Promoting inclusion, cultural appreciation,
              and community empowerment through awareness
              and solidarity with Aeta communities.
            </p>
          </div>

          <div className="advocacy-grid">
            {advocacies.map((advocacy) => (
              <AdvocacyCard
                key={advocacy.id}
                icon={advocacy.icon}
                title={advocacy.title}
                description={advocacy.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* MISSION AND VISION SECTION */}
      <MissionVision />
    </main>
  );
}

export default Home;
