const advocacies = [
  {
    id: 1,
    icon: "🎓",
    title: "Education for All",
    description:
      "Promoting awareness of accessible and inclusive education for Aeta children and youth, while respecting Indigenous knowledge and learning traditions."
  },
  {
    id: 2,
    icon: "🌿",
    title: "Cultural Preservation",
    description:
      "Celebrating Indigenous identities, traditions, and cultural heritage while encouraging respect for the voices and experiences of Aeta communities."
  },
  {
    id: 3,
    icon: "🤝",
    title: "Community Empowerment",
    description:
      "Encouraging community participation, meaningful partnerships, and awareness of sustainable livelihood opportunities led by Indigenous communities."
  }
];

export default advocacies;
