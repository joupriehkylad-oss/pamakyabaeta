const team = [
  {
    id: 1,
    name: "Kyla Jouprieh Domingo",
    role: "Team Member",
    image: "/images/team/default.png"
  },
  {
    id: 2,
    name: "John Vladimir Gopez",
    role: "Team Member",
    image: "/images/team/default.png"
  },
  {
    id: 3,
    name: "Lance Quan",
    role: "Team Member",
    image: "/images/team/default.png"
  },
  {
    id: 4,
    name: "Marc Jan Manalo",
    role: "Team Member",
    image: "/images/team/default.png"
  },
  {
    id: 5,
    name: "John Rafael Garcia",
    role: "Team Member",
    image: "/images/team/default.png"
  }
];

export default team;
